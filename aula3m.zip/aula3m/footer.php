	<footer>
        <p style="background-image: linear-gradient(180deg, red, yellow);">Este é o Rodapé<p> 
    </footer>