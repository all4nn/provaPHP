<p>Data de nascimento</p>
<form action="./?p=nascimento"  method="post">
    <label> Dia: </label>
    <input type="text" name="dia"><br>
    <label> Mes: </label>
    <input type="text" name="mes"><br>
    <input type="submit">
</form>
<?php
    if (isset($_POST["dia"])){
        echo "Dia: ".$_POST["dia"]."<br>";
        echo "Mes: ".$_POST["mes"];
    }else{
        echo "Envie seu nascimento";
    }

?>
<hr>
<img src="ima/we.jpeg" width= "250">
<hr>
<br>