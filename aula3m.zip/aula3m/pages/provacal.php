<?php

function somar($valor1, $valor2, $valor3){
    return $valor1 + $valor2 + $valor3;
}

?>