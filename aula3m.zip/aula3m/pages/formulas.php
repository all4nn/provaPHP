<?php
/*
function somar($valor1, $valor2){
    return $valor1 + $valor2;
}
function diminuir($valor1, $valor2){
    return $valor1 - $valor2;
}
function multi($valor1, $valor2){
    return $valor1 * $valor2;
}
function divi($valor1, $valor2){
    return $valor1 / $valor2;
}
*/

function divi($valor1, $valor2){
    if($valor1 == 0 || $valor2 == 0){   
        echo "O valor tem que ser diferente de 0";
    }else{
        return $valor1 / $valor2;
    }
}

?>

