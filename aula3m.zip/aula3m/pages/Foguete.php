<p> este é o foguete</p>
<?php
$i = 10;
while($i >= 1){
    echo "$i <br>";
    $i--;
}
echo "Voar, voar, subir, subir <br>"; 
?>
<hr>
<img src="ima/fog.gif" width= "250">