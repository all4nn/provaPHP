<p> aqui é a prova </p>

<?php

require_once "./pages/provacal.php";
if(isset($_POST["op"])){
    $op = $_POST["op"];
    $v1 = (float)$_POST["valor1"];
    $v2 = (float)$_POST["valor2"];
    $v3 = (float)$_POST["valor3"];
    echo "<hr>";
    echo gettype($v1);
    echo "<br> $v1";
    echo "<hr>";

    if($op == ""){
        echo "Escolha uma operação";
    }else{
        switch($op){
            case "somar":
                echo "O resultado da Soma é : " .somar($v1, $v2, $v3);
            break;
            default:
                echo "Escolha uma operação válida";
            break;
        }
    }
}



?>

<form method="post">
    <label>Valor 1: </label><br>
    <input type="text" name="valor1"><br><br>
    <label>Valor 2: </label><br>
    <input type="text" name="valor2"><br><br>
    <label>Valor 3: </label><br>
    <input type="text" name="valor3"><br><br>
    <label>Operação :</label><br>
    <input type="text" name="op"><br><br>
    <input type="submit"><br>
</form>

