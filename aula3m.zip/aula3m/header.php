<h3 style="background-image: linear-gradient(rgba(42, 202, 175, 0.938), rgb(168, 17, 206));">(: Este é o Header</h3>

<a id="home" href="?p=home">Home</a>&nbsp;|&nbsp;
    <a id="sobreNos" href="?p=sobreNos"target="_self">Sobre Nós</a>&nbsp;|&nbsp;
    <a href="?p=contato">Contato</a> | 
    <a href="?p=calcular">Calcular</a> |
    <a href="?p=Foguete">Foguetinho</a> |
    <a href="?p=prova">Prova</a> |
    <a href="?p=nascimento">Nascimento</a>